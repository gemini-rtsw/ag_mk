# epics-base-314.spec -- Gemini EPICS base R3.14.12.8, host + RTEMS 4.10 cross
#
# DRAFT: pending MANIFEST.txt from tools/collect-ade-sources.sh. Two things
# must be confirmed before the first build:
#   1. that the collected tree really is source (src/ + configure/), and
#   2. how RTEMS_BASE/RTEMS_VERSION are spelled in its
#      configure/os/CONFIG_SITE.Common.RTEMS -- 3.14's variable names differ
#      from 7.x and the overrides below are written for 3.14.
#
# Named "epics-base-314", NOT "epics-base". The rpm-repo already holds
# epics-base-7.0.7 and epics-base-3.14.12 (the latter host-only, no cross
# build, and with no mvme2307 target at all). A third name lets all three
# coexist and makes the pins in consuming specs unambiguous.
#
# This one is built from source rather than repackaged, because a prebuilt
# EPICS tree carries absolute /gem_sw paths through configure/ and envPaths.
# Rebuilding with FINAL_LOCATION set is what makes it relocatable.

%global _enable_debug_package 0
%global debug_package %{nil}
%global __os_install_post /usr/lib/rpm/brp-compress %{nil}
%global _missing_build_ids_terminate_build 0

%define name          epics-base-314
%define epics_ver     3.14.12.8
%define prefix_dir    /gem_base/epics/epics-base-%{epics_ver}
%define rtems_prefix  /gem_base/targetOS/RTEMS/rtems/4.10
%define host_arch     linux-x86_64
%define cross_archs   RTEMS-mvme2307 RTEMS-mvme3100
%define git_hash %(if [ -n "$GIT_HASH" ]; then echo "$GIT_HASH"; else git rev-parse --short HEAD 2>/dev/null || echo nogit; fi)

Name:           %{name}
Version:        3.14.12.8
Release:        0.%{git_hash}%{?dist}
Summary:        EPICS base R3.14.12.8 (Gemini), host and RTEMS 4.10 cross builds
License:        EPICS Open License
Source0:        epics-base-R3.14.12.8-src.tar.gz
Prefix:         %{prefix_dir}
ExclusiveArch:  x86_64

BuildRequires:  rtems410 = 4.10%{?dist}
BuildRequires:  gcc gcc-c++ make perl-interpreter perl-FindBin perl-File-Copy perl-lib
BuildRequires:  readline-devel
Requires:       rtems410 = 4.10%{?dist}
Requires:       readline

%description
EPICS base R3.14.12.8 as patched and used at Gemini, built for the host
(%{host_arch}) and cross-built for the RTEMS 4.10 targets %{cross_archs}.

The mvme2307 target is a Gemini addition -- stock EPICS 3.14.12 ships
mvme2100/2700/3100/5500 only -- which is why the shared epics-base-3.14.12
package cannot be used for the A&G and other VME IOCs.

%package devel
Summary:        Headers, configure/ and templates for building against %{name}
Requires:       %{name} = %{version}-%{release}
Requires:       rtems410 = 4.10%{?dist}
%description devel
Headers, build rules and templates needed to compile an IOC or support module
against EPICS base R3.14.12.8.

%prep
%setup -q -n base

%build
export EPICS_HOST_ARCH=%{host_arch}
# FINAL_LOCATION bakes the INSTALLED path into the generated configure/ files
# and scripts, instead of the transient rpmbuild directory.
export FINAL_LOCATION=%{prefix_dir}

# Point base at the RTEMS 4.10 toolchain from the rtems410 package and build
# only the targets we actually ship. Passed on the make command line so the
# collected tree's own CONFIG_SITE files stay untouched.
make \
    RTEMS_VERSION=4.10 \
    RTEMS_BASE=%{rtems_prefix} \
    CROSS_COMPILER_TARGET_ARCHS="%{cross_archs}"

%install
export DONT_STRIP=1
rm -rf $RPM_BUILD_ROOT
mkdir -p $RPM_BUILD_ROOT%{prefix_dir}

for d in bin lib include dbd db startup templates configure; do
    [ -d $d ] && cp -r $d $RPM_BUILD_ROOT%{prefix_dir}/
done
find $RPM_BUILD_ROOT%{prefix_dir} -name '.svn' -prune -exec rm -rf {} + 2>/dev/null || :

# Refuse to ship a base that silently built host-only -- that failure mode is
# exactly what makes the existing epics-base-3.14.12 package unusable here, and
# it is invisible until an IOC fails to link months later.
for a in %{cross_archs}; do
    test -d "$RPM_BUILD_ROOT%{prefix_dir}/lib/$a" || {
        echo "ERROR: cross build for $a produced no lib/$a -- refusing to package" >&2
        exit 1; }
done

# The Gemini build rules (CONFIG.Gem, RULES.Gem, convertGemRelease.pl) come
# from the gemini-ade package, which installs them under the EPICS 7 base at
# /gem_base/epics/epics-base. An IOC's configure/CONFIG does
# `-include $(EPICS_BASE)/configure/CONFIG.Gem`, so they must also be reachable
# from THIS base. Symlink rather than copy, so there is one source of truth and
# an ade upgrade is picked up.
mkdir -p $RPM_BUILD_ROOT%{prefix_dir}/bin/%{host_arch}
for f in CONFIG.Gem RULES.Gem RULES_TOP.Gem; do
    ln -sf /gem_base/epics/epics-base/configure/$f \
           $RPM_BUILD_ROOT%{prefix_dir}/configure/$f
done
ln -sf /gem_base/epics/epics-base/bin/%{host_arch}/convertGemRelease.pl \
       $RPM_BUILD_ROOT%{prefix_dir}/bin/%{host_arch}/convertGemRelease.pl

mkdir -p $RPM_BUILD_ROOT%{_sysconfdir}/profile.d
cat > $RPM_BUILD_ROOT%{_sysconfdir}/profile.d/epics-base-314.sh <<EOF
export EPICS_BASE_314=%{prefix_dir}
EOF

%files
%defattr(-,root,root)
%dir %{prefix_dir}
%{prefix_dir}/bin
%{prefix_dir}/lib
%{prefix_dir}/dbd
%{prefix_dir}/db
%{prefix_dir}/startup
%{_sysconfdir}/profile.d/epics-base-314.sh

%files devel
%defattr(-,root,root)
%{prefix_dir}/include
%{prefix_dir}/configure
%{prefix_dir}/templates

%changelog
* Thu Aug 28 2026 Hawi Stecher <hawi.stecher@noirlab.edu> - 3.14.12.8-0
- Initial packaging of the Gemini EPICS 3.14.12.8 base with RTEMS 4.10 cross
  builds for mvme2307 and mvme3100, shared by the EPICS 3.14 IOCs.
