# rtems410.spec -- Gemini RTEMS 4.10 PowerPC cross-toolchain + BSPs
#
# DRAFT: the %install path assumes the tarball unpacks to a single top-level
# directory. Confirm against MANIFEST.txt from tools/collect-ade-sources.sh
# before the first build.
#
# This is a REPACKAGE, not a build. The toolchain is gcc 4.4.7 / Newlib 1.18.0
# from 2012 (RSB ad29cd659d886c448e0b8ed240f833f4cf437478); rebuilding it from
# the RTEMS Source Builder on a modern host is not realistic -- gcc 4.4.7 does
# not compile under a current host gcc without substantial patching. The
# binaries are frozen and will never legitimately change, so we ship them
# as-is.
#
# Deliberately named "rtems410", NOT "rtems": the pipeline already has
# rtems-6.2 at /gem_base/targetOS/RTEMS/rtems/6, and EPICS 3.14 and EPICS 7
# packages must be able to coexist on one build host.

%global _enable_debug_package 0
%global debug_package %{nil}
# Prebuilt cross binaries: skip the post-install processing that assumes native
# ELF and would mangle or fail on them.
%global __os_install_post %{nil}
%global _missing_build_ids_terminate_build 0
# noarch by convention (a self-contained tree under /gem_base) but it holds
# x86_64 host binaries -- same exception rtems.spec takes for RTEMS 6.
%global _binaries_in_noarch_packages_terminate_build 0

%define name          rtems410
%define rtems_major   4.10
%define rtems_prefix  /gem_base/targetOS/RTEMS/rtems/%{rtems_major}
%define git_hash %(if [ -n "$GIT_HASH" ]; then echo "$GIT_HASH"; else git rev-parse --short HEAD 2>/dev/null || echo nogit; fi)

Name:           %{name}
Version:        4.10
Release:        0.%{git_hash}%{?dist}
Summary:        RTEMS 4.10 PowerPC cross-toolchain and BSPs (mvme2307, mvme3100)
License:        GPLv2 and GPLv3 and BSD-2-Clause
URL:            https://www.rtems.org/
Source0:        rtems-4.10-gem.tar.gz
BuildArch:      noarch

# Nothing is compiled -- this only unpacks and relocates a prebuilt tree.
BuildRequires:  tar gzip findutils

%description
RTEMS 4.10 PowerPC cross development tools (gcc 4.4.7, Newlib 1.18.0) and the
Gemini board support packages for mvme2307 and mvme3100, installed under
%{rtems_prefix}.

Consumed by epics-base-314, which cross-builds EPICS 3.14.12.8 for the
RTEMS-mvme2307 and RTEMS-mvme3100 targets. Kept separate from the "rtems"
package (RTEMS 6.2) so both toolchains can be installed side by side.

%prep
# -c because the tarball's top directory is "rtems-4.10", not "%{name}-%{version}".
%setup -q -c -n %{name}-%{version}

%build
# Nothing to build. See the header.
:

%install
rm -rf $RPM_BUILD_ROOT
mkdir -p $RPM_BUILD_ROOT%{rtems_prefix}

# The tarball unpacks as ./rtems-4.10/... -- move its CONTENTS to the prefix so
# the toolchain lands at %{rtems_prefix}/bin, not %{rtems_prefix}/rtems-4.10/bin.
src=$(ls -d rtems-4.10 2>/dev/null || ls -d */ | head -1)
cp -a "$src"/. $RPM_BUILD_ROOT%{rtems_prefix}/

# Fail loudly if the BSPs the IOCs actually target are missing, rather than
# shipping a toolchain that cannot link them.
for bsp in mvme2307 mvme3100; do
    test -d "$RPM_BUILD_ROOT%{rtems_prefix}/powerpc-rtems4.10/$bsp" || {
        echo "ERROR: BSP $bsp missing from the toolchain tree" >&2; exit 1; }
done
test -x "$RPM_BUILD_ROOT%{rtems_prefix}/bin/powerpc-rtems4.10-gcc" || {
    echo "ERROR: powerpc-rtems4.10-gcc not found under bin/" >&2; exit 1; }

# Make the toolchain reachable without every consumer hard-coding the prefix.
mkdir -p $RPM_BUILD_ROOT%{_sysconfdir}/profile.d
cat > $RPM_BUILD_ROOT%{_sysconfdir}/profile.d/rtems410.sh <<EOF
export RTEMS410_BASE=%{rtems_prefix}
EOF

%files
%defattr(-,root,root,-)
%dir %{rtems_prefix}
%{rtems_prefix}/*
%{_sysconfdir}/profile.d/rtems410.sh

%changelog
* Thu Aug 28 2026 Hawi Stecher <hawi.stecher@noirlab.edu> - 4.10-0
- Initial repackage of the frozen RTEMS 4.10 toolchain from
  /gem_sw/targetOS/RTEMS/rtems-4.10, for the EPICS 3.14 IOCs that cannot move
  to EPICS 7 / RTEMS 6.
